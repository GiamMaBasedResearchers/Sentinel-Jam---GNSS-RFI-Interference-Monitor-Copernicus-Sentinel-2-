@echo off
rem ============================================================
rem  SENTINEL JAM - quick start on Windows (Python standard lib only)
rem  1. Checks files  2. Checks Python  3. Starts server and opens the browser
rem ============================================================
title Sentinel Jam - local server
cd /d "%~dp0"

if not exist "sentinel-server.py" goto :nopyfile
if not exist "sentinel-jam-monitor.html" goto :nohtml

set "PYCMD="
where python >nul 2>nul
if not errorlevel 1 set "PYCMD=python"
if defined PYCMD goto :pyok

where py >nul 2>nul
if not errorlevel 1 set "PYCMD=py"
if defined PYCMD goto :pyok

goto :nopython

:pyok
echo.
echo  Starting Sentinel Jam on http://localhost:8123 ...
echo  (keep this window open; Ctrl+C to stop)
echo.
start "" /min cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8123/"
%PYCMD% sentinel-server.py 8123
echo.
echo  Server stopped.
pause
exit /b 0

:nopyfile
echo.
echo  [ERROR] "sentinel-server.py" is missing!
echo.
echo  This .bat needs THESE 3 files in the SAME folder:
echo    - start-rinex.bat  (this file)
echo    - sentinel-server.py  (local server + download proxy)
echo    - sentinel-jam-monitor.html  (the app)
echo.
echo  SIMPLEST SOLUTION: download the full package
echo  "sentinel-jam-monitor-python.zip" which already contains
echo  everything, extract it into a folder and double-click start-rinex.bat.
echo.
pause
exit /b 1

:nohtml
echo.
echo  [ERROR] "sentinel-jam-monitor.html" is missing in the same folder
echo  as this .bat file. Download "sentinel-jam-monitor-python.zip".
echo.
pause
exit /b 1

:nopython
echo.
echo  [ERROR] Python not found.
echo  Install it from https://www.python.org/downloads/windows/
echo  and tick "Add python.exe to PATH" during installation.
echo.
pause
exit /b 1
