#!/usr/bin/env python3
# Sentinel-2 AUX_GNSSRD dataset downloader for sentinel-jam-monitor.html
# Downloads the daily GNSS RINEX (AUX_GNSSRD) products of three fixed 6-day
# windows into three separate folders created in the CURRENT working directory
# (the folder you launch the script from):
#   dataset-2018-10/   validity 2018-10-10 .. 2018-10-15   (S2A + S2B era)
#   dataset-2022-10/   validity 2022-10-10 .. 2022-10-15   (S2A + S2B era)
#   dataset-2026-10/   validity 2026-10-10 .. 2026-10-15   (S2B + S2C era)
#
# The catalogue search (OData) is anonymous. Product download needs a FREE
# Copernicus Data Space account: credentials are taken from the CDSE_USER /
# CDSE_PASS environment variables or asked once in the terminal and NEVER
# stored (password grant, same mechanism as the CDSE login chip of the web app).
# Files already present with the expected size are skipped (safe re-runs).
# Each folder also gets a manifest.txt (product name + validity window).
# Stdlib only, no dependencies.
#
# Usage:  python download-datasets.py            (search + download all three)
#         python download-datasets.py 2022       (one dataset only: 2018|2022|2026)
#         python download-datasets.py --check    (search only, no login needed)
#
# Result: 3 folders with .TGZ products (~3 MB each, ~14 products per folder,
# 2 files per day - one per active satellite). Analyse them offline in the web
# app: RINEX content analysis -> Local RINEX files -> PICK FILES -> ANALYZE.
import getpass, json, os, re, sys, time, urllib.error, urllib.parse, urllib.request

ODATA = 'https://catalogue.dataspace.copernicus.eu/odata/v1/Products'
TOKEN_URL = 'https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token'

# Validity OVERLAP windows: files whose covered day intersects the range, the
# same rule the web app uses for its UTC date-range query (a daily AUX_GNSSRD
# file covering day D starts ~23:59:46 of D-1, so a pure start-date filter
# would drop exactly the first requested day).
DATASETS = [
    {'key': '2018', 'folder': 'dataset-2018-10', 'from': '2018-10-10T00:00:00.000Z', 'to': '2018-10-15T23:59:59.999Z'},
    {'key': '2022', 'folder': 'dataset-2022-10', 'from': '2022-10-10T00:00:00.000Z', 'to': '2022-10-15T23:59:59.999Z'},
    {'key': '2026', 'folder': 'dataset-2026-10', 'from': '2026-10-10T00:00:00.000Z', 'to': '2026-10-15T23:59:59.999Z'},
]


def odata_filter(ds):
    return ("Online eq true and Collection/Name eq 'SENTINEL-2' and "
            "Attributes/OData.CSC.StringAttribute/any(i0: i0/Name eq 'productType' and i0/Value eq 'AUX_GNSSRD') and "
            "ContentDate/End ge " + ds['from'] + " and ContentDate/Start le " + ds['to'])


def search(ds):
    prods, top = [], 100
    while True:
        qs = urllib.parse.urlencode({'$filter': odata_filter(ds), '$orderby': 'ContentDate/Start asc',
                                     '$top': str(top), '$skip': str(len(prods)), '$count': 'true'})
        url = ODATA + '?' + qs.replace('+', '%20')
        with urllib.request.urlopen(url, timeout=90) as r:
            j = json.loads(r.read().decode())
        val = j.get('value', [])
        prods += val
        try:
            counted = int(j.get('@odata.count') or 0)
        except (TypeError, ValueError):
            counted = 0
        if len(val) < top or (counted and len(prods) >= counted):
            break
    return prods


def get_token(user, pwd):
    data = urllib.parse.urlencode({'grant_type': 'password', 'client_id': 'cdse-public',
                                   'username': user, 'password': pwd}).encode()
    with urllib.request.urlopen(urllib.request.Request(TOKEN_URL, data=data), timeout=90) as r:
        return json.loads(r.read().decode())['access_token']


def download(pid, dest, state):
    url = ODATA + '(%s)/$value' % pid
    for attempt in range(4):
        req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + state['tok']})
        try:
            with urllib.request.urlopen(req, timeout=600) as r, open(dest + '.part', 'wb') as f:
                total = 0
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
                    total += len(b)
            os.replace(dest + '.part', dest)
            return total
        except urllib.error.HTTPError as e:
            if os.path.exists(dest + '.part'):
                os.remove(dest + '.part')
            if e.code == 401 and attempt == 0:
                state['tok'] = get_token(state['user'], state['pwd'])  # token expired
                continue
            if e.code in (429, 500, 502, 503, 504):
                time.sleep(2 * (attempt + 1))
                continue
            raise
    raise RuntimeError('download failed after retries')


def main():
    args = sys.argv[1:]
    check = '--check' in args
    only = [a for a in args if re.fullmatch(r'(2018|2022|2026)', a)]
    datasets = [d for d in DATASETS if not only or d['key'] in only]
    if not datasets:
        print('No dataset selected. Use 2018 | 2022 | 2026 (see --help in the header).')
        return
    state = {'tok': None, 'user': os.environ.get('CDSE_USER', ''), 'pwd': os.environ.get('CDSE_PASS', '')}
    if not check:
        if not state['user']:
            print('CDSE login (free account: dataspace.copernicus.eu - used once, nothing is stored)')
            state['user'] = input('  email: ').strip()
            state['pwd'] = getpass.getpass('  password: ')
        try:
            state['tok'] = get_token(state['user'], state['pwd'])
            print('Token OK, starting downloads...\n')
        except urllib.error.HTTPError as e:
            print('Login failed: HTTP %d (%s)' % (e.code, e.reason))
            return
        except Exception as e:
            print('Login failed:', e)
            return
    grand, nfiles = 0, 0
    for d in datasets:
        # folder created where you RUN the script (current working directory)
        os.makedirs(d['folder'], exist_ok=True)
        print('=== dataset %s : validity %s .. %s -> %s/' % (d['key'], d['from'][:10], d['to'][:10], d['folder']))
        try:
            prods = search(d)
        except Exception as e:
            print('  catalogue search failed:', e)
            continue
        if not prods:
            print('  no AUX_GNSSRD products found in this window')
            continue
        plats = {}
        for p in prods:
            plats.setdefault(p['Name'][:3], []).append(p)
        for k in sorted(plats):
            print('  %-3s %2d product(s)' % (k, len(plats[k])))
        print('  total: %d product(s)' % len(prods))
        if check:
            for p in sorted(prods, key=lambda x: x['Name']):
                print('    ' + p['Name'])
            continue
        for p in sorted(prods, key=lambda x: x['Name']):
            fname = p['Name'] if p['Name'].lower().endswith(('.tgz', '.zip')) else p['Name'] + '.tgz'
            dest = os.path.join(d['folder'], fname)
            size = int(p.get('ContentLength') or 0)
            if os.path.exists(dest) and (not size or os.path.getsize(dest) == size):
                print('  skip (already on disk): %s' % fname)
                continue
            try:
                n = download(p['Id'], dest, state)
            except Exception as e:
                print('  FAILED %s -> %s' % (fname, e))
                continue
            grand += n
            nfiles += 1
            print('  saved %s (%.1f MB)' % (fname, n / 1e6))
            time.sleep(0.4)  # gentle pacing, CDSE throttles bulk downloads
        with open(os.path.join(d['folder'], 'manifest.txt'), 'w', encoding='utf-8') as f:
            f.write('# Sentinel-2 AUX_GNSSRD products, validity overlap %s .. %s (UTC)\n'
                    '# analyse offline with sentinel-jam-monitor.html -> Local RINEX files\n'
                    % (d['from'][:10], d['to'][:10]))
            for p in sorted(prods, key=lambda x: x['Name']):
                cd = p.get('ContentDate') or {}
                f.write('%s\t%s -> %s\n' % (p['Name'], cd.get('Start', ''), cd.get('End', '')))
    if not check:
        print('\nDone: %d new file(s), %.1f MB downloaded' % (nfiles, grand / 1e6))
        print('Open sentinel-jam-monitor.html -> RINEX content analysis ->')
        print('Local RINEX files -> PICK FILES (all files of one dataset folder) -> ANALYZE LOCAL FILES.')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nInterrupted.')
    except urllib.error.HTTPError as e:
        print('Failed: HTTP %d (%s)' % (e.code, e.reason))
        sys.exit(1)
    except Exception as e:
        print('Error:', e)
        sys.exit(1)
