#!/usr/bin/env bash
# SENTINEL JAM - local server start (Python 3, standard library only)
cd "$(dirname "$0")" || exit 1

if [ ! -f sentinel-server.py ] || [ ! -f sentinel-jam-monitor.html ]; then
  echo "[ERROR] sentinel-server.py and sentinel-jam-monitor.html are required"
  echo "in the SAME folder as this script (download sentinel-jam-monitor-python.zip)."
  exit 1
fi

PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then
  echo "[ERROR] Python 3 not found: https://www.python.org/downloads/"
  exit 1
fi

echo "Starting Sentinel Jam on http://localhost:8123 ..."
echo "(keep the terminal open; Ctrl+C to stop)"
( sleep 2; xdg-open http://localhost:8123/ 2>/dev/null || open http://localhost:8123/ 2>/dev/null ) &
"$PY" sentinel-server.py 8123
