#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SENTINEL JAM - local server (Python standard library only, zero installs)

What it does:
  1. Serves the sentinel-jam-monitor.html app on http://localhost:8123
  2. Proxy /cdse/dl  -> downloads RINEX products from the Copernicus download
     endpoint SERVER-SIDE (no CORS, no 400 "Malformed OData request path"
     errors typical of browsers from file://)
  3. Proxy /cdse/nodes -> list of a product's internal files (public)

Usage:
  python sentinel-server.py [port]      (default 8123)
  then open:  http://localhost:8123/
"""
import json
import os
import sys
import urllib.request
import urllib.error
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8123
ODATA_DL = "https://download.dataspace.copernicus.eu/odata/v1/Products"
UA = "Mozilla/5.0 (compatible; SentinelJamLocal/1.0)"

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".json": "application/json; charset=utf-8",
    ".ico": "image/x-icon",
}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # ---------- helpers ----------
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "X-CDSE-Token, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _options(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ---------- static ----------
    def _static(self, path):
        if path in ("/", ""):
            path = "/sentinel-jam-monitor.html"
        rel = urllib.parse.unquote(path.lstrip("/"))
        full = os.path.normpath(os.path.join(HERE, rel))
        if not full.startswith(HERE) or not os.path.isfile(full):
            self._json(404, {"error": "not found", "path": rel})
            return
        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        size = os.path.getsize(full)
        rng = self.headers.get("Range")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-cache")
        self._cors()
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(full, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)

    # ---------- CDSE proxy ----------
    def _cdse_get(self, url, token, stream=False):
        headers = {"User-Agent": UA}
        if token:
            headers["Authorization"] = "Bearer " + token
        req = urllib.request.Request(url, headers=headers)
        try:
            return urllib.request.urlopen(req, timeout=120), None
        except urllib.error.HTTPError as e:
            raw = e.read() or b""
            detail = {}
            try:
                detail = json.loads(raw.decode("utf-8", "replace"))
            except Exception:
                detail = {"message": raw.decode("utf-8", "replace")[:300] or ("HTTP " + str(e.code))}
            return None, (e.code, detail)
        except Exception as e:
            return None, (502, {"message": "CDSE non raggiungibile: %s" % e})

    def _cdse_dl(self, qs):
        pid = (qs.get("id") or [""])[0].strip()
        name = (qs.get("name") or [""])[0].strip()
        token = self.headers.get("X-CDSE-Token") or (qs.get("token") or [""])[0]
        if not pid:
            self._json(400, {"message": "parametri richiesti: id"})
            return
        if token:
            # token JWT non deve finire nei log
            print("[dl] prodotto=%s (con token)" % pid)
        else:
            print("[dl] prodotto=%s (SENZA token)" % pid)
        # Catena di forme URL (v10.3): prima il metodo UFFICIALE della
        # documentazione CDSE (Products(id)/$value -> ZIP del prodotto),
        # poi i nodi interni non quotati, infine il legacy quotato.
        base = "%s(%s)" % (ODATA_DL, urllib.parse.quote(pid, safe=""))
        shapes = [(base + "/$value", "intero-$value")]
        if name:
            qn = urllib.parse.quote(name, safe="")
            shapes.append(("%s/Nodes(%s)/$value" % (base, qn), "nodo-nonquotato"))
            shapes.append(("%s/Nodes('%s')/$value" % (base, qn), "nodo-quotato"))
        errors = []
        for url, label in shapes:
            resp, err = self._cdse_get(url, token, stream=True)
            if err:
                code, detail = err
                errors.append("%s:%s" % (label, code))
                print("[dl] forma %s -> ERRORE %s: %s" % (label, code, json.dumps(detail)[:160]))
                continue
            clen = resp.headers.get("Content-Length")
            self.send_response(200)
            self.send_header("Content-Type", resp.headers.get("Content-Type") or "application/octet-stream")
            if clen:
                self.send_header("Content-Length", clen)
            self._cors()
            self.end_headers()
            total = 0
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
                total += len(chunk)
            print("[dl] OK forma=%s %s byte" % (label, total))
            return
        # tutte le forme fallite: 401 se tutte 401 (cosi' l'app mostra il hint login),
        # altrimenti 502 con la matrice dei tentativi
        if errors and all(e.endswith(":401") for e in errors):
            self._json(401, {"message": "Token non valido o assente (CDSE 401)"})
            return
        self._json(502, {"message": "download fallito [" + ", ".join(errors) + "]"})

    def _cdse_nodes(self, qs):
        pid = (qs.get("id") or [""])[0].strip()
        token = self.headers.get("X-CDSE-Token") or ""
        if not pid:
            self._json(400, {"message": "parametro richiesto: id"})
            return
        url = "%s(%s)/Nodes" % (ODATA_DL, urllib.parse.quote(pid, safe=""))
        resp, err = self._cdse_get(url, token)
        if err:
            code, detail = err
            self._json(code, detail)
            return
        data = resp.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    # ---------- routing ----------
    def do_OPTIONS(self):
        self._options()

    def do_HEAD(self):
        self._static(self.path)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        try:
            if parsed.path == "/cdse/dl":
                self._cdse_dl(urllib.parse.parse_qs(parsed.query))
            elif parsed.path == "/cdse/nodes":
                self._cdse_nodes(urllib.parse.parse_qs(parsed.query))
            elif parsed.path == "/ping":
                self._json(200, {"ok": True, "server": "sentinel-jam-local", "port": PORT})
            else:
                self._static(parsed.path)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._json(500, {"message": "internal error: %s" % e})
            except Exception:
                pass

    def log_message(self, fmt, *args):
        pass  # logging already handled in the proxy functions


def main():
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print("=" * 60)
    print(" SENTINEL JAM — server locale attivo")
    print(" Apri nel browser:  http://localhost:%d/" % PORT)
    print(" (Ctrl+C per fermare)")
    print("=" * 60)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nServer fermato.")


if __name__ == "__main__":
    main()
